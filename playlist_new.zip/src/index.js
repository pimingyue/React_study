import React from 'react';
import ReactDOM from 'react-dom';
import Header from './header';
import Main from './main';
import Footer from './footer';




class MusicApp extends React.Component{
    constructor(){
        super(...arguments);
        this.state = {
            listState:true,
            data:[
                {
                    title:"空白格",
                    singer:'蔡健雅',
                    selected:true,
                    like:false
                },
                {
                    title:"空白格2222",
                    singer:'蔡健雅2222',
                    selected:true,
                    like:true
                },
                {
                    title:"空白格3333",
                    singer:'蔡健雅3333',
                    selected:false,
                    like:true
                }
            ],
        };
        this.add=this.add.bind(this)
        this.setCheckAll = this.setCheckAll.bind(this)
        this.setCheck=this.setCheck.bind(this)
        this.setLike=this.setLike.bind(this)
        this.remove=this.remove.bind(this)
        this.removeSelect=this.removeSelect.bind(this)
        this.collectLike=this.collectLike.bind(this)
        this.cancelLike=this.cancelLike.bind(this)
        this.likeList=this.likeList.bind(this)
        this.showLikeList=this.showLikeList.bind(this)

    }
    add(title,singer){
        let data = this.state.data;
        data.push({
            title:title,
            singer:singer,
            selected:false,
            like:false
        });
        this.setState({
            data
        })
    }
    isCheckAll(){
        let data = this.state.data;
        for (let i=0; i<data.length;i++){
            if (!data[i].selected){
                return false;
            }
        }
        return true;
    }
    setCheckAll(checked) {
        let data = this.state.data.map((val)=>{
            val.selected = checked;
            return val;
        });
        this.setState({
            data
        })
    }
    setCheck(index,checked){
        let data = this.state.data;
        data[index].selected = checked;
        this.setState({
            data
        })
    }
    setLike(index,checked){
        let data = this.state.data;
        data[index].like = checked;
        this.setState({
            data
        })
    }
    remove(index){
        let data = this.state.data.filter((val,i)=>i!==index);
        this.setState({
            data
        })
    }
    removeSelect(){
        let  data = this.state.data.filter((val)=>!val.selected);
        this.setState({
            data
        })
    }
    collectLike(){
        let  data = this.state.data.map((val,index)=>{
            if (val.selected){
                val.like = true
            }
            return val
        });
        this.setState({
            data
        })
    }
    cancelLike(){
        let  data = this.state.data.map((val,index)=>{
            if (val.selected){
                val.like = false
            }
            return val
        });
        this.setState({
            data
        })
    }
    likeList(){
        let  data = this.state.data.filter((val)=> val.like);
        this.setState({
            data
        })
    }
    showLikeList(state){
        this.setState({
            listState:state
        })
    }
    render(){
        let data = this.state.data;
        let selectData = data.filter((val)=>val.selected)
        let collect = data.filter((val)=>val.like)
        return (
            <div id="musicApp">
                <Header
                    add={this.add}
                />
                <Main data={this.state.listState?data:collect}
                      isCheckAll={this.isCheckAll()}
                      checkAll={this.setCheckAll}
                      setCheck={this.setCheck}
                      setLike={this.setLike}
                      remove={this.remove}
                />
                <Footer
                    length={data.length}
                    selectLength={selectData.length}
                    collect={collect.length}
                    listState={this.state.listState}
                    removeSelect={this.removeSelect}
                    collectLike={this.collectLike}
                    cancelLike={this.cancelLike}
                    likeList={this.likeList}
                />
            </div>
        )
    }
}


ReactDOM.render(
    <MusicApp/>,
    document.getElementById('root'));
