import React from 'react';
import Item from "./item";

export default class Main extends React.Component{
    render(){
        return(
            <table
                className="main"
                style={{
                    display:this.props.data.length?'table':'none'
                }}
            >
                <thead>
                    <tr>
                        <th>
                            <input
                                type="checkbox"
                                id="checkAll"
                                checked={this.props.isCheckAll}
                                onChange={(e)=>{
                                    this.props.checkAll(e.target.checked);
                                }}
                            />
                            <label htmlFor="checkAll">全选</label>
                        </th>
                        <th>歌曲</th>
                        <th>歌手</th>
                        <th>收藏</th>
                        <th>删除</th>
                    </tr>
                </thead>
                <tbody>
                    {/*<Item/>*/
                        this.props.data.map((val,index)=>{
                            return (
                                <Item
                                    key={index}
                                    data={val}
                                    index={index}
                                    setCheck={this.props.setCheck}
                                    setLike={this.props.setLike}
                                    remove={this.props.remove}
                                />
                            )
                        })
                    }

                </tbody>
            </table>
        )
    }
}